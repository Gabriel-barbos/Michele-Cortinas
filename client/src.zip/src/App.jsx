import { AppRoutes } from "./pages/Routes";

export default function App() {
  return ( 
      <>
      <AppRoutes />
      </>
  )
}
