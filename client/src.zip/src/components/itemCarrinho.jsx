import '../assets/css/itemCarrinho.css'

import cortinaRed from '../assets/img-teste/cortina-vermelha.jpg'
export function ItemCarrinho(){

return(

<div className="boxCard" >
<img className="imgprodIcon" alt="" src={cortinaRed} />
<h2 className="titulo">Cortina Blackout 3</h2>
<h3 className="cor">{`Cor: Cinza Concreto `}</h3>
<p className="desc">persiana com 3 estagios</p>
<div
  className="valor"
>{`Valor Aproximado:  R$250,00 `}</div>

<div className="larguraAltura">
  <p className="largura">Largura:</p>
  <p className="altura">Altura:</p>
</div>
<button className="editBtn">
  <div className="editBtnChild" />
  <div className="editar">editar</div>
</button>
<button className="deleteBtn">
  <div className="deleteBtnChild" />
  <div className="excluir">excluir</div>
</button>
<div className="medidas">
  <p className="Mlargura">2,20m </p>
  <p className="Malturs">1,85m</p>
</div>
</div>

)
}