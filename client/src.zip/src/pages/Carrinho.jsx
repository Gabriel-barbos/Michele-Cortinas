import '../assets/css/carrinho.css'
import { ItemCarrinho } from '../components/itemCarrinho'
export function Carrinho(){
    return(
        <>
<header className="header" />
    <h1 className="carrinho">Carrinho</h1>
      <ItemCarrinho />
      <div className="carrinho-Card">
        <div className="carrinho-Box" />
        <h2 className="total">TOTAL: 750 R$</h2>
        <button className="sendBtn">
          <div className="enviar">Checkout</div>
        </button>

        <div className="enderecoBox">
          <div className="enderecoBox1" />
          <div className="enderecoDeEntrega">Endereço de entrega:</div>
          <div className="alterar">alterar</div>
          <div className="endereco">

            <p>rua da Bahia, 345 - ap 416 <br />
              Cidade baixa <br />
              Xique-Xique,BA <br />
            </p> 
        
          </div>
        </div>
      </div>
      <footer className="footer" />
        </>
    )
}