import { PedidoADM } from "../components/PedidoADM";
import '../assets/css/pedidosAdm.css'
export function PedidosADM() {
    return (
       <>
       <h1>Pedidos</h1>
       <PedidoADM />
       </>
    )
}